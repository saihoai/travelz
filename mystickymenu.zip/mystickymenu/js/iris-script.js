jQuery(document).ready(function($){
    $('.my-color-field').wpColorPicker();
});