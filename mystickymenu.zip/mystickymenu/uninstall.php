<?php
	if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit;
	if ( get_option( 'mysticky_option_name' ) != false ) {
		delete_option( 'mysticky_option_name' );
	}

