<?php
$template = get_option( 'template' );
switch($template){

	default :
		echo '</main></div>';
		break;
}