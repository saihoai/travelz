<div id="wpbooking_order_calendar" class="clear">
	<div class="calendar-wrap"></div>
	<div class="clear"></div>
</div>
