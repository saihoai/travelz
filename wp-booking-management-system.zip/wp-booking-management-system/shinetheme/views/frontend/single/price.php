<div class="price-wrapper" itemprop="offers" itemscope itemtype="http://schema.org/Offer">

	<p class="price"><?php echo wpbooking_service_price_html() ?></p>

	<meta itemprop="price" content="<?php echo wpbooking_service_price() ?>" />
	<meta itemprop="priceCurrency" content="<?php echo WPBooking_Currency::get_current_currency('name') ?>" />
</div>
