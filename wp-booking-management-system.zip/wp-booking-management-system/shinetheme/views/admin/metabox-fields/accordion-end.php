<div class="clear"></div>
</div><!--End .wpbooking-metabox-accordion-content-->
</div><!--End .wpbooking-metabox-accordion-->

