<div class="wpbooking-metabox-accordion">
	<h4 class="wpbooking-accordion-title"><i class="fa fa-arrow-circle-right"></i> <?php echo esc_html( $data['label'] ); ?></h4>
	<div class="wpbooking-metabox-accordion-content clearfix">

