<?php
/**
 * Created by WpBooking Team.
 * User: NAZUMI
 * Date: 12/15/2016
 * Version: 1.0
 */

?>
<div class="wb-breadcrumb-room wb-room-form">
    <a href="#" class="wb-all-rooms"><?php echo esc_html__('Room details','wpbookinf'); ?></a> /
    <span><?php echo ($data['new_text'])?></span>
</div>
