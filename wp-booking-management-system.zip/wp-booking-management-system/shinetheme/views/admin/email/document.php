<ol>
	<li>[order_id] : <?php esc_html_e('Order ID','wpbooking') ?></li>
	<li>[name_customer] : <?php esc_html_e('Name Customer','wpbooking') ?></li>
	<li>[order_status] : <?php esc_html_e('Order Status','wpbooking') ?></li>
	<li>[order_total] : <?php esc_html_e('Order Total','wpbooking') ?></li>
	<li>[order_payment_gateway] : <?php esc_html_e('Order Payment Gateway','wpbooking') ?></li>
	<li>[order_table] : <?php esc_html_e('Order Table','wpbooking') ?></li>
	<li>[checkout_info]: <?php esc_html_e('Checkout Form Information','wpbooking') ?> </li>
</ol>