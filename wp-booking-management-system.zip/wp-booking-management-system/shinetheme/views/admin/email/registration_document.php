<ol>
	<li>[user_login] : <?php esc_html_e('Username','wpbooking') ?></li>
	<li>[user_email]: <?php esc_html_e('User Email','wpbooking') ?> </li>
	<li>[user_pass]: <?php esc_html_e('User Password (Random Default Password, User should change it after logging in)','wpbooking') ?> </li>
	<li>[profile_url]: <?php esc_html_e('URL to My Account Page','wpbooking') ?> </li>
	<li>[edit_user_url]: <?php esc_html_e('[For Admin] URL to Edit User Page','wpbooking') ?> </li>
</ol>